Please import sql file first to install it correctly

Install ME.sql file in current folder for fresh installation

After importing 'INSTALL ME' file, be sure to set your connection info to communicate correctly with your Database

Database file is located in 

Connect.php



The default admin login info is admin / admin



Last updated - 30th July 2018